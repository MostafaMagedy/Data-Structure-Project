class EnrollmentNode {
    int id; // Can be student ID or course ID depending on context
    EnrollmentNode next;
    EnrollmentNode prev;
    
    public EnrollmentNode(int id) {
        this.id = id;
        this.next = null;
        this.prev = null;
    }
}

class EnrollmentList {
    EnrollmentNode head;
    EnrollmentNode tail;
    
    public EnrollmentList() {
        head = tail = null;
    }
    
    public void add(int id) {
        EnrollmentNode newNode = new EnrollmentNode(id);
        if (tail == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }
    
    public void remove(int id) {
        if (head == null) return;
        
        EnrollmentNode current = head;
        while (current != null && current.id != id) {
            current = current.next;
        }
        
        if (current == null) return; // ID not found
        
        if (current == head && current == tail) {
            head = tail = null;
        } else if (current == head) {
            head = head.next;
            if (head != null) head.prev = null;
        } else if (current == tail) {
            tail = tail.prev;
            if (tail != null) tail.next = null;
        } else {
            current.prev.next = current.next;
            current.next.prev = current.prev;
        }
    }
    
    public boolean contains(int id) {
        EnrollmentNode current = head;
        while (current != null) {
            if (current.id == id) return true;
            current = current.next;
        }
        return false;
    }
    
    public void display() {
        EnrollmentNode current = head;
        while (current != null) {
            System.out.print(current.id);
            if (current.next != null) {
                System.out.print(" <-> ");
            }
            current = current.next;
        }
        System.out.println();
    }
}

// Node to map a Course ID to its list of students
class CourseEnrollmentNode {
    int courseId;
    EnrollmentList students;
    CourseEnrollmentNode next;
    CourseEnrollmentNode prev;
    
    public CourseEnrollmentNode(int courseId) {
        this.courseId = courseId;
        this.students = new EnrollmentList();
        this.next = null;
        this.prev = null;
    }
}

class StudentEnrollmentNode {
    int studentId;
    EnrollmentList courses;
    StudentEnrollmentNode next;
    StudentEnrollmentNode prev;
    
    public StudentEnrollmentNode(int studentId) {
        this.studentId = studentId;
        this.courses = new EnrollmentList();
        this.next = null;
        this.prev = null;
    }
}

public class EnrollmentSystem {
    private CourseEnrollmentNode courseHead;
    private StudentEnrollmentNode studentHead;
    
    public EnrollmentSystem() {
        courseHead = null;
        studentHead = null;
    }
    
    private CourseEnrollmentNode findCourseNode(int courseId) {
        CourseEnrollmentNode current = courseHead;
        while (current != null) {
            if (current.courseId == courseId) return current;
            current = current.next;
        }
        return null;
    }
    
    private StudentEnrollmentNode findStudentNode(int studentId) {
        StudentEnrollmentNode current = studentHead;
        while (current != null) {
            if (current.studentId == studentId) return current;
            current = current.next;
        }
        return null;
    }
    
    private CourseEnrollmentNode createCourseNode(int courseId) {
        CourseEnrollmentNode newNode = new CourseEnrollmentNode(courseId);
        if (courseHead == null) {
            courseHead = newNode;
        } else {
            CourseEnrollmentNode temp = courseHead;
            while (temp.next != null) temp = temp.next;
            temp.next = newNode;
            newNode.prev = temp;
        }
        return newNode;
    }
    
    private StudentEnrollmentNode createStudentNode(int studentId) {
        StudentEnrollmentNode newNode = new StudentEnrollmentNode(studentId);
        if (studentHead == null) {
            studentHead = newNode;
        } else {
            StudentEnrollmentNode temp = studentHead;
            while (temp.next != null) temp = temp.next;
            temp.next = newNode;
            newNode.prev = temp;
        }
        return newNode;
    }
    
     public void enrollStudent(int studentId, int courseId) {
        
        CourseEnrollmentNode courseNode = findCourseNode(courseId);
        if (courseNode == null) courseNode = createCourseNode(courseId);
        
        StudentEnrollmentNode studentNode = findStudentNode(studentId);
        if (studentNode == null) studentNode = createStudentNode(studentId);
        
        if (!courseNode.students.contains(studentId)) {
            courseNode.students.add(studentId);
        }
        
        if (!studentNode.courses.contains(courseId)) {
            studentNode.courses.add(courseId);
        }
    }
        
    public void unenrollStudent(int studentId, int courseId) {
        CourseEnrollmentNode courseNode = findCourseNode(courseId);
        StudentEnrollmentNode studentNode = findStudentNode(studentId);
        
        // Remove student from course's list
        if (courseNode != null) {
            courseNode.students.remove(studentId);
            
            // If course has no students left, remove it from the system
            if (courseNode.students.head == null) {
                if (courseNode.prev != null) {
                    courseNode.prev.next = courseNode.next;
                } else {
                    courseHead = courseNode.next; // Update head if removing first node
                }
                if (courseNode.next != null) {
                    courseNode.next.prev = courseNode.prev;
                }
            }
        }
        
        // Remove course from student's list
        if (studentNode != null) {
            studentNode.courses.remove(courseId);
            
            // If student has no courses left, remove them from the system
            if (studentNode.courses.head == null) {
                if (studentNode.prev != null) {
                    studentNode.prev.next = studentNode.next;
                } else {
                    studentHead = studentNode.next; // Update head if removing first node
                }
                if (studentNode.next != null) {
                    studentNode.next.prev = studentNode.prev;
                }
            }
        }
    }
    
    public void displayStudentsInCourse(int courseId) {
        CourseEnrollmentNode courseNode = findCourseNode(courseId);
        if (courseNode != null) {
            System.out.println("Students enrolled in course " + courseId + ":");
            courseNode.students.display();
        } else {
            System.out.println("Course " + courseId + " not found.");
        }
    }
    
    public void displayCoursesForStudent(int studentId) {
        StudentEnrollmentNode studentNode = findStudentNode(studentId);
        if (studentNode != null) {
            System.out.println("Courses enrolled by student " + studentId + ":");
            studentNode.courses.display();
        } else {
            System.out.println("Student " + studentId + " not found.");
        }
    }
    
    public boolean isEnrolled(int studentId, int courseId) {
        StudentEnrollmentNode studentNode = findStudentNode(studentId);
        CourseEnrollmentNode courseNode = findCourseNode(courseId);
        
        return studentNode != null && courseNode != null &&
               studentNode.courses.contains(courseId) &&
               courseNode.students.contains(studentId);
    }
    
    public void isNormalStudent(int studentId) {
        StudentEnrollmentNode studentNode = findStudentNode(studentId);
        if (studentNode == null) {
            System.out.println("There isn't any Student with this ID");
            return;
        }
        else{
        int count = 0;
        EnrollmentNode current = studentNode.courses.head;
        while (current != null) {
            count++;
            current = current.next;
        }
        if(count>=2 && count<=7){
            System.out.println("Normal Student has registered in "+count+" Courses");
        }
        else{
            System.out.println("Not a Normal Student has registered in "+count+" Courses");
        }
        
    }
    }
    
    public void isFullCourse(int courseId) {
        CourseEnrollmentNode courseNode = findCourseNode(courseId);
        if (courseNode == null) {
            System.out.println("There isn't any Course with this ID");
            return;
        }
        else{
        int count = 0;
        EnrollmentNode current = courseNode.students.head;
        while (current != null) {
            count++;
            current = current.next;
        }
        if(count>=0 && count<=29){
            System.out.println("The Course isn't Full yet,there is "+(30-count)+" place remaining");
        }
        else{
            System.out.println("This Course is full");
        }   
    }
    }
    public void sortCoursesForStudent(int studentId) {
        StudentEnrollmentNode studentNode = findStudentNode(studentId);
        if (studentNode == null) {
            System.out.println("Student " + studentId + " not found.");
            return;
        }
        
        EnrollmentNode current;
        boolean swapped;
        
        do {
            swapped = false;
            current = studentNode.courses.head;
            
            while (current != null && current.next != null) {
                if (current.id > current.next.id) {
                    // Swap the IDs
                    int temp = current.id;
                    current.id = current.next.id;
                    current.next.id = temp;
                    swapped = true;
                }
                current = current.next;
            }
        } while (swapped);
    }
    
    public void sortStudentsInCourse(int courseId) {
        CourseEnrollmentNode courseNode = findCourseNode(courseId);
        if (courseNode == null) {
            System.out.println("Course " + courseId + " not found.");
            return;
        }
        
        EnrollmentNode current;
        boolean swapped;
        
        do {
            swapped = false;
            current = courseNode.students.head;
            
            while (current != null && current.next != null) {
                if (current.id > current.next.id) {
                    // Swap the IDs
                    int temp = current.id;
                    current.id = current.next.id;
                    current.next.id = temp;
                    swapped = true;
                }
                current = current.next;
            }
        } while (swapped);
    }
    
}