
class courseNode extends University{
    courseNode next=null;
    courseNode prev=null;
    
    public courseNode(int cor_id){
        this.cor_id=cor_id;
    }
}


class Courses extends University{
    courseNode head = null;
    courseNode tail=null;
    public int last;

    public void sortCourses(){
        
        for(int i =0;i<count-1;i++){
            courseNode current = head;
            for(int j =0;j<count - i - 1; j++){
                if(current.cor_id > current.next.cor_id){
                    temp = current.cor_id;
                    current.cor_id=current.next.cor_id;
                    current.next.cor_id = temp;
                }
                current = current.next;
            }
        }
        courseNode i = head;
        int index =1;
        System.out.println("Sorted Courses List :-");
        while(i!=null){
            System.out.println("Course ID : "+i.cor_id+" , Index : "+index);
            i=i.next;
            index++;
        }  
    }
        

    public void Display_Courses(){
        courseNode i =head;
        int index = 1;
    if (i !=null) {
        System.out.println("Course registered in the system: ");
        while(i !=null){
            System.out.println("Course ID : "+i.cor_id+"  , Index : "+index);
            i=i.next;
            index++;
        }
    }    
    else{
            System.out.println("There isn't any registered Courses in the system: ");
        }
    }

    public void addhead(int cor_id){
        courseNode newNode = new courseNode(cor_id);

        if(head == null){
            head = tail = newNode;
        }else{
            newNode.next=head;
            head.prev=newNode;
            head = newNode;
        }
        count++;
        last = cor_id;

    }
    public void addCourse(int cor_id){// هنستخدمها علشان لما نيجي نضيف كورس هنضيف للاخر كدا كدا(add to tail)
        

        courseNode newNode = new courseNode(cor_id);
        
        if(tail ==null){
            head = tail = newNode;
        }else{
            tail.next = newNode;
            newNode.prev = tail;
            tail=newNode;
        }
        count++;
        last = cor_id;
        
    }
    
    public void deletehead(){
        if(head == null)return;

        head=head.next;
        if (head != null) {
            head.prev=null;
        }
        count--;
    }
    
    public void removeCourse(int cor_id){
        

        if (head == null) {
            System.out.println("No Course to remove");
            return;
        }
        if(head.cor_id ==cor_id){
            deletehead();
            return;
        }
        courseNode i =head;
        while(i!=null && i.cor_id!=cor_id){
            i=i.next;
        }
        if(i==null){
            System.out.println("Course : "+cor_id+" not found !");
            return;
        }
        if(i.next!=null){
            i.next.prev=i.prev;
        }
        if(i.prev!=null){
            i.prev.next=i.next;
        }
        count--;
        last = tail.prev.cor_id;
        
    }
    
    public void getLastCourseAdded(){
        if(tail==null){
            System.out.println("System is Empty");
        }else{System.out.println("Last Course Added is : "+last);}
    }

    public boolean isCourse_exist(int cor_id1){
        courseNode current = head;
        for(int i =0;i<count;i++){
            System.out.println("count = "+count);
            if(current.cor_id == cor_id1){
                return true;
            }
            else{current = current.next;} 
        }
        return false;
    }
    
}