
class Student {
    private int id;
    private StudentCourseLL courseHead;  // this attribute counts as the head for the linked list of courses
    private int totalCoursesEnrolled;

    public Student(){
    }
    public Student(int id){
        this.id = id;
    }

    public void setId(int id){
        this.id = id;
    }

    public int getId(){
        return this.id;
    }

    public void setCourseHead(StudentCourseLL courses) {
        this.courseHead = courses;
    }

    public StudentCourseLL getCourses() {
        return courseHead;
    }

    public int getTotalCoursesEnrolled(){return totalCoursesEnrolled;}

    public void incrementTotalCoursesEnrolled(){
        this.totalCoursesEnrolled++;
    }

    public void decrementTotalCoursesEnrolled(){
        this.totalCoursesEnrolled--;
    }

    public void isNormalStudent(){
        if (totalCoursesEnrolled >= 2 && totalCoursesEnrolled <=7){
            System.out.println("Student "+this.getId()+" is normal");
        }else if(totalCoursesEnrolled < 2){
            System.out.println("Student "+this.getId()+" does not have enough courses enrolled");
        }else{
            System.out.println("Student "+this.getId()+" has more courses enrolled than allowed");
        }
    }
}

