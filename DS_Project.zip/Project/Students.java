
class studentNode extends University{
    studentNode next;
    studentNode prev;
    
    public studentNode(int std_id){
        this.std_id=std_id;
    }
}

class Students extends University{
    static studentNode head = null;
    static studentNode tail=null;
    public static int last;

    public Students(){

    }

    public void getLastStudentAdded(){
        System.out.println("Last Student ID added: " + last);
        
    }

    public void addStudent(int std_id){
        studentNode newNode = new studentNode(std_id);
        std_count++;
        if(head == null && tail == null){
            head = tail = newNode;
        }else{
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        last = newNode.std_id;

        System.out.println("Student "+ std_id + " has been added to the system");

    }

    public void deletehead(){
        if(head == null)return;

        head=head.next;
        if (head != null) {
            head.prev=null;
        }
        count--;
    }
   
    public void removeStudent(int std_id){
        if (head == null) {
            System.out.println("No Student to remove");
            return;
        }
        if(head.std_id ==std_id){
            deletehead();
            return;
        }
        studentNode i =head;
        while(i!=null && i.std_id!=std_id){
            i=i.next;
        }
        if(i==null){
            System.out.println("Student : "+std_id+" not found !");
            return;
        }
        else{
        if(i.next!=null){
            i.next.prev=i.prev;
        }
        if(i.prev!=null){
            i.prev.next=i.next;
        }
        count--;
        last = tail.prev.std_id;
        System.out.println("Student "+std_id+" is removed succesfully");
    }
        
    }

    public void displayStudentsById(){
        studentNode i =head;
        int index = 1;
        
        if(i !=null){
            System.out.println("Students registered in the system: ");
        while(i !=null){
            System.out.println("Student ID : "+i.std_id+"  , Index : "+index);
            i=i.next;
            index++;
        }
    }
    else {
            System.out.println("There isn't any registered Students in the system: ");
        }
    }


    public void sortStudentsInSystemById(){

        if(head == null || head.next == null){  // 1 student or less
            System.out.println("There are not enough students in the system to sort");
            return;
        }

        studentNode prev = null;
        studentNode current = head;
        studentNode next1 = current.next;
        studentNode temp = null;
        boolean switched = true;
        while(switched){
            prev = null;   // reset all indicators at the start of the loop
            current = head;
            next1 = current.next;
            switched = false;
            if(current.std_id > next1.std_id && current == head){ // reassign head of LL
                current.next=next1.next;
                next1.next =current;
                head = next1;
                switched = true;

                prev = next1;
                current = next1.next;  // increment prev current and next
                if(current != null){     // reassign next to be after current
                    next1 = current.next;
                }
            }else{   // no swaps done, just reassign
                prev = current;
                current = next1;
                next1 = next1.next;
            }
            for(; next1 != null; prev = current, current = next1, next1 = next1.next) {
                if (current.std_id > next1.std_id) { // swapping any node except head
                    prev.next = next1;
                    current.next = next1.next;
                    next1.next = current;

                    switched = true;
                    temp = current;
                    current = next1;
                    next1 = temp;
                }
            }
        }
    }
    public boolean isStudent_exist(int std_id1){
        studentNode current = head;
        for(int i =0;i<std_count;i++){
            System.out.println("count = "+std_count);
            if(current.std_id == std_id1){
                return true;
            }
            else{current = current.next;} 
        }
        return false;
    }
}
