
public class StudentCourseLL{
    private int courseID;
    private StudentCourseLL nextCourse;

    public StudentCourseLL(){}
    public StudentCourseLL(int courseId){
        this.courseID = courseId;
    }
    public void setCourseID(int courseID){
        this.courseID = courseID;
    }
    public int getCourseID() {
        return courseID;
    }

    public void setNextCourse(StudentCourseLL nextCourse) {
        this.nextCourse = nextCourse;
    }

    public StudentCourseLL getNextCourse(){
        return nextCourse;
    }

}
