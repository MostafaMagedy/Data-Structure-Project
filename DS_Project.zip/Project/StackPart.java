public class StackPart extends University{

    int[][] actionWithOpposite = {{1,2},{3,4},{5,6}};

    /* example:
     *    [1,2]   1 will call addstudent, 2 will call removestudent
     *    [3,4]   3 will call addcourse, 4 calls removecourse etc...
     */
    main_Area mainArea = new main_Area();
    Students studentList = new Students();
    Courses courseList = new Courses();

    /*public static void main(String[] args){  // test main, please ignore
        Scanner input = new Scanner(System.in);
        main_Area mainArea = new main_Area();
        StackPart stack = new StackPart();
        Students studentList = new Students();
        Courses courseList = new Courses();
        // uses only 2 stacks not 2, an undo stack(also counts as items stack) and redo stack

        int userInput;
        while (true) {
            System.out.println("Enter action, to exit enter -1, to undo enter -2, to redo enter -3: ");
            userInput = input.nextInt();

            if (userInput == -1){
                break;
            }else if (userInput == -2) {
                stack.undoAction();
            }else if (userInput == -3) {
                stack.redoAction();
            }else {
                mainArea.executeAction(userInput);
                stack.pushUndo(userInput);
                stack.clearRedo();
            }
        }
    }*/

    public void undoAction(){
        if (isEmptyUndo()){
            System.out.println("theres nothing to undo");
        }else{
            int val = popUndo();
            // find opposite of val using a 2x2 array storing [[action, opposite action]]
            int oppositeVal = lookForOpposite(val, actionWithOpposite);
            // execute opposite
            mainArea.executeAction(oppositeVal);
            pushRedo(val);
        }
    }

    public void redoAction() {
        if (isEmptyRedo()) {
            System.out.println("theres nothing to redo");
        } else {
            int val = popRedo();
            mainArea.executeAction(val);
            pushUndo(val);
        }
    }

    public static int lookForOpposite(int action, int[][] actionsWithOpposite){
        for(int i = 0; i < actionsWithOpposite.length; i++){
            if(actionsWithOpposite[i][0] == action){
                return actionsWithOpposite[i][1];  // looks for value in second column
            }
            if(actionsWithOpposite[i][1] == action){
                return actionsWithOpposite[i][0];
            }
        }
        return -1; // no opposite found, e.g the function is displayCourses(), has no opposite
    }


    private int maxSize=50;
    private int undoTop = -1;
    private int[] undoStack = new int[maxSize];
    private int redoTop = -1;
    private int[] redoStack = new int[maxSize];
    public StackPart (){
    }

    public boolean isEmptyUndo(){//to check if the undo Stack are empty or not
        
        if(undoTop==-1)
            return true;
        else 
            return false;      
    }
    public boolean isEmptyRedo(){//to check if the redo Stack are empty or not
        
        if(redoTop==-1)
            return true;
        else 
            return false;      
    }
    
   public void pushUndo(int element){
      if(undoTop < maxSize - 1){
         undoTop++;
         undoStack[undoTop] =element ;
      }
      else
        System.out.println("Sorry your Stack is full");
   }

    public void pushRedo(int element){
        if(redoTop < maxSize - 1){
            redoTop++;
            redoStack[redoTop] =element ;
        }
        else
            System.out.println("Sorry your Stack is full");
    }

   public int popRedo(){
       if (!isEmptyRedo()){
           int popped = redoStack[redoTop];
           redoStack[redoTop] = 0;
           redoTop--;
           return popped;
       } else
           System.out.println("Redo stack is empty");
       return -1;
   }
    public int popUndo(){
      if (!isEmptyUndo()){
          int popped = undoStack[undoTop];
          undoStack[undoTop] = 0;
          undoTop--;
          return popped;
      } else 
            System.out.println("Undo stack is empty");
            return -1;
    }

    public void clearRedo(){
        for(int i = 0; i < maxSize -1; i++){
            redoStack[i] = 0;
        }
        redoTop = -1;
    }
    
    /*public void undo(){
        if(!isEmptyUndo()){
            top++;
            items[top]=undoStack[undoTop];
            redoTop++;
            redoStack[redoTop]=undoStack[undoTop];
            undoTop--;
        }
        else 
            System.out.println("Sorry the undo Stack is Empty");    
    } */
    
    /*public void redo(){
        if(!isEmptyRedo()){ 
            undoTop++;
            undoStack[undoTop]=items[top];
            top--;
            redoTop--;
        }
        else 
            System.out.println("Sorry the redo Stack is Empty");
    }
      
       public void getStack(){
           System.out.print("[ ");
           for (int i = top; i >= 0; i--) {
               System.out.print(items[i]);
               System.out.print(" ");
           }
           System.out.println("]");
       }*/
}


