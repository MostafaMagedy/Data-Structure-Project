import java.util.Scanner;

public class main_Area{
    int[][] actionWithOpposite = {{1,2},{3,4},{5,6}};

    Students studentList = new Students();
    Courses courseList = new Courses();
    EnrollmentSystem enrollsys = new EnrollmentSystem();

    public static void main(String[] args){

        Scanner input = new Scanner(System.in);
        main_Area mainArea = new main_Area();
        StackPart stack = new StackPart();

        System.out.println("Welcome to the University system!");
        System.out.println("==============================================================");
        System.out.println("Please input the desired action based on the given number:");
        System.out.println("1.To add a student\n2.To remove a student\n3.To add a course\n4.To remove a course\n" +
                "5.To enroll a student in a course\n6.To remove a student's enrollment from a course\n" +
                "7.To list the courses taken by a specific student\n8.To list the students enrolled in a specific course\n" +
                "9.To list the total courses in the system\n10.To list the total students in the system\n" +
                "11.To sort the courses by their id for a specific student\n12.To sort students by their id for a specific course\n" +
                "13.To sort courses by their id\n14.To sort students by their id\n" +
                "15.To get the last course added\n16.To get the last student added\n" +
                "17.To check if a course is full\n18.To check if a student is normal");
        System.out.println("==============================================================");
        int userInput;
        while (true) {
            System.out.println("Enter your action, to exit enter -1, to undo enter -2, to redo enter -3: ");
            userInput = input.nextInt();

            if (userInput == -1){
                break;
            }else if (userInput == -2) {
                stack.undoAction();
            }else if (userInput == -3) {
                stack.redoAction();
            }else {
                mainArea.executeAction(userInput);
                if(userInput == 1 || userInput == 2 || userInput == 3 || userInput == 4 ||
                userInput == 5 || userInput == 6){   // will only push to undo if the function has an opposite
                    stack.pushUndo(userInput);
                    stack.clearRedo();
                }
            }
        }
    }

    public void executeAction(int actionVal){
        Scanner input = new Scanner(System.in);
        // massive switch case with all functions for the user to select from
        switch(actionVal){
            case 1: // add student
                System.out.println("==============================================================");
                System.out.println("Enter student id to create: ");
                int std_id = input.nextInt();
                studentList.addStudent(std_id);
                System.out.println("Action completed successfully");
                System.out.println("==============================================================");
                break;
            case 2: // remove student
                System.out.println("==============================================================");
                System.out.println("Enter student id to remove: ");
                int st_id = input.nextInt();
                studentList.removeStudent(st_id);
                System.out.println("Action completed successfully");
                System.out.println("==============================================================");
                break;
            case 3: // add course
                System.out.println("==============================================================");
                System.out.println("Enter course id to add: ");
                int cor_id = input.nextInt();
                courseList.addCourse(cor_id);
                System.out.println("Action completed successfully");
                System.out.println("==============================================================");
                break;
            case 4: // remove course
                System.out.println("==============================================================");
                System.out.println("Enter course id to remove: ");
                int cour_id = input.nextInt();
                courseList.removeCourse(cour_id);
                System.out.println("==============================================================");
                break;
            case 5://enroll a student in a course
                System.out.println("Enter Student ID : ");
                int stdID = input.nextInt();
                System.out.println("Enter Course ID : ");
                int corID = input.nextInt();

                if(courseList.isCourse_exist(corID) && studentList.isStudent_exist(stdID)){// to check if course and student exist or not 
                    enrollsys.enrollStudent(stdID, corID);
                }else{
                    System.out.println("Course or Student not Found");
                }
                break;
            case 6:// remove enrollment
                System.out.println("Enter Student ID : ");
                int stdID_R = input.nextInt();
                System.out.println("Enter Course ID : ");
                int corID_R = input.nextInt();
                enrollsys.unenrollStudent(stdID_R, corID_R);
                break;
            case 7: // display courses of student
                System.out.println("Enter Student ID : ");
                int stdID_D = input.nextInt();
                enrollsys.displayCoursesForStudent(stdID_D);
                break;
            case 8:// display students of a course
                System.out.println("Enter Course ID : ");
                int corID_D = input.nextInt();
                enrollsys.displayStudentsInCourse(corID_D);
                break;
            case 9:
                System.out.println("==============================================================");
                courseList.Display_Courses();
                System.out.println("==============================================================");
                break;
            case 10:
                System.out.println("==============================================================");
                studentList.displayStudentsById();
                System.out.println("==============================================================");
                break;
            case 11:
                System.out.println("Enter student ID : ");
                int stdID_Sort = input.nextInt();
                enrollsys.sortCoursesForStudent(stdID_Sort);
                break;
            case 12:
                System.out.println("Enter Course ID : ");
                int corID_Sort = input.nextInt();
                enrollsys.sortStudentsInCourse(corID_Sort);
                break;
            case 13:
                System.out.println("==============================================================");
                courseList.sortCourses();
                System.out.println("==============================================================");
                break;
            case 14:
                System.out.println("==============================================================");
                studentList.sortStudentsInSystemById();
                studentList.displayStudentsById();
                System.out.println("==============================================================");
                break;
            case 15:
                System.out.println("==============================================================");
                courseList.getLastCourseAdded();
                System.out.println("==============================================================");
                break;
            case 16:
                System.out.println("==============================================================");
                studentList.getLastStudentAdded();
                System.out.println("==============================================================");
                break;
            case 17:
                System.out.println("Enter course ID : ");
                int corID_FULL = input.nextInt();
                enrollsys.isFullCourse(corID_FULL);
                break;
            case 18:
                System.out.println("Enter student ID : ");
                int stdID_normal = input.nextInt();
                enrollsys.isNormalStudent(stdID_normal);
                break;
            default:
                System.out.println("Sorry, the number you entered is invalid, please try again");
                break;
        }
    }
}

