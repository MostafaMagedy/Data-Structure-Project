
class University{// الكلاس الكبيرة الي هربط بيها كل حاجة ببعض
    protected boolean fullCourse,noramlStudent;
    
    
    protected int cor_id,std_id;

    protected static int std_count,count;
    
    protected static int StudentInCourse,CourseInStudent;
    
    protected int temp;
}


